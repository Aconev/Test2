import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JButton;
import javax.swing.JFrame;


public class GuiViewTest extends GuiView{
	
		public static void main(String[] args) {
				
			JFrame window = new JFrame();
			window.setBounds(250,250, 600, 600);
			window.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
			window.setVisible(true);
			window.setLayout(null);
			
			JButton b1 = new JButton("red");
			b1.setBounds(0, 0, 100, 100);
			b1.setBackground(Color.red);
			window.add(b1);
			b1.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					color = Color.red;
				}
				});
			
			JButton b2 = new JButton("blue");
			b2.setBounds(0, 100, 100, 100);
			b2.setBackground(Color.blue);
			window.add(b2);
			b2.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					color = Color.blue;
				}
				});
			
			JButton b3 = new JButton("green");
			b3.setBounds(0, 200, 100, 100);
			b3.setBackground(Color.green);
			window.add(b3);
			b3.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					color = Color.green;
				}
				});
			
			JButton b4 = new JButton("yellow");
			b4.setBounds(0, 300, 100, 100);
			b4.setBackground(Color.yellow);
			window.add(b4);
			b4.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					color = Color.yellow;
				}
				});
			
			JButton b5 = new JButton("magenta");
			b5.setBounds(0, 400, 100, 100);
			b5.setBackground(Color.magenta);
			window.add(b5);
			b5.addActionListener(new ActionListener() {
				@Override
				public void actionPerformed(ActionEvent e) {
					color = Color.magenta;
				}
				});
			
			GuiView p = new GuiView();
			p.setBounds(100, 0, 470, 600);
			p.setBackground(Color.white);
			window.add(p);
			
			
			
			
			
		
	};
	
}

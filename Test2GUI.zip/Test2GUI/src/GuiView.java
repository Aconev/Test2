

import java.awt.Color;
import java.awt.Graphics;
import java.awt.Graphics2D;
import java.awt.event.MouseEvent;
import java.awt.event.MouseListener;
import java.awt.event.MouseMotionListener;
import java.awt.geom.Ellipse2D;
import java.awt.geom.Line2D;

import javax.swing.JButton;
import javax.swing.JComponent;
import javax.swing.JFrame;

public class GuiView extends JComponent{
	
	private double[] points = new double[6];
	private int index = 0;
	
	public static Color color = Color.RED;
	
	private int movePointX = -1;
	private int movePointY = -1;
	
	
	public GuiView()
	{
		super();
		setBackground(Color.WHITE);
		addMouseMotionListener(new MouseMotionListener() {

			@Override
			public void mouseDragged(MouseEvent e) {
				
				if(movePointX != -1 && movePointY != -1) {
					points[movePointX] = e.getX();
					points[movePointY] = e.getY();	
					repaint();
				}
			}

			@Override
			public void mouseMoved(MouseEvent e) {
				
			}
			
		});
		addMouseListener(new MouseListener() {

			@Override
			public void mouseClicked(MouseEvent e) {
				
				if(index <points.length){
					points[index] = e.getX();
					points[index+1] = e.getY();
					index += 2;
					repaint();
				}
			}

			@Override
			public void mousePressed(MouseEvent e) {
				int x = e.getX();
				int y = e.getY();
				for(int i = 0; i<index; i+=2){
					if( points[i]-5 < x && x < points[i]+5 && points[i+1]-5 < y && y < points[i+1]+5){
						movePointX = i;
						movePointY = i+1;
						break;
					}
				}
			}

			@Override
			public void mouseReleased(MouseEvent e) {
				movePointX = -1;
				movePointY = -1;
			}

			@Override
			public void mouseEntered(MouseEvent e) {
				
				
			}

			@Override
			public void mouseExited(MouseEvent e) {
				
				
			}
			
		});
		
		
	}
	
	
	private double medianX;
	private double medianY;
	
	public void paintComponent(Graphics g){
		
		super.paintComponent(g);
		Graphics2D g2d = (Graphics2D) g;
		g2d.setColor(getBackground());
		g2d.fillRect(getBounds().x, getBounds().y, getBounds().width,getBounds().height);
			
		if(index > 0){
			
			for(int i = 0; i<index; i+=2){
				
				g2d.setColor(color);
				Ellipse2D ellipse = new Ellipse2D.Double(points[i]-5, points[i+1]-5, 10, 10);
				g2d.draw(ellipse);
				g2d.fill(ellipse);
				
			}
		}
		if(index == 6){
			
			g2d.setColor(Color.BLACK);
			Line2D line1 = new Line2D.Double(points[0], points[1], points[2], points[3]);
			Line2D line2 = new Line2D.Double(points[2], points[3], points[4], points[5]);
			Line2D line3 = new Line2D.Double(points[4], points[5], points[0], points[1]);
			g2d.draw(line1);
			g2d.draw(line2);
			g2d.draw(line3);
			
				if(points[0] < points[2]) {
					medianX = points[0] + (points[2]-points[0])/2; 
				}else {
					medianX = points[2] + (points[0]-points[2])/2;
				}
				if(points[1] < points[3]) {
					medianY = points[1] + (points[3]-points[1])/2;
				}else {
					medianY = points[3] + (points[1]-points[3])/2;
				}
				
				Line2D line4 = new Line2D.Double(points[4], points[5], medianX, medianY);
				
				if(points[2] < points[4]) {
					medianX = points[2] + (points[4]-points[2])/2; 
				}else {
					medianX = points[4] + (points[2]-points[4])/2;
				}
				if(points[3] < points[5]) {
					medianY = points[3] + (points[5]-points[3])/2;
				}else {
					medianY = points[5] + (points[3]-points[5])/2;
				}
				
				Line2D line5 = new Line2D.Double(points[0], points[1], medianX, medianY);
				
				if(points[0] < points[4]) {
					medianX = points[0] + (points[4]-points[0])/2; 
				}else {
					medianX = points[4] + (points[0]-points[0])/2;
				}
				if(points[1] < points[5]) {
					medianY = points[1] + (points[5]-points[1])/2;
				}else {
					medianY = points[5] + (points[1]-points[5])/2;
				}
			
				Line2D line6 = new Line2D.Double(points[2], points[3], medianX, medianY);
				
			g2d.draw(line4);
			g2d.draw(line5);
			g2d.draw(line6);
			
			
		}
		
		
	}
	
}
